#ifndef __HELP__
#define __HELP__


int launches(char* executable);

unsigned int calculate_checksum(struct tar_t* entry);

#endif